﻿

namespace Shared
    {
    public enum EventType
        {
        PUBLIC, PRIVATE
        };
    }
